import logo from './logo.svg';
import './App.css';
import Tourdetail from './Components/TourDetails/TourDetails';

function App() {
  return (
     <>
    <Tourdetail/>
    </>
  );
}

export default App;
